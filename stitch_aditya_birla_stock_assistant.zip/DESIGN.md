---
name: Birla Wealth Intelligence
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#4c4451'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#7d7482'
  outline-variant: '#cfc2d2'
  surface-tint: '#7c43ab'
  primary: '#3e0069'
  on-primary: '#ffffff'
  primary-container: '#581c87'
  on-primary-container: '#ca8efc'
  inverse-primary: '#e0b6ff'
  secondary: '#006c4f'
  on-secondary: '#ffffff'
  secondary-container: '#59fdc5'
  on-secondary-container: '#007354'
  tertiary: '#570007'
  on-tertiary: '#ffffff'
  tertiary-container: '#80000f'
  on-tertiary-container: '#ff837c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f2daff'
  primary-fixed-dim: '#e0b6ff'
  on-primary-fixed: '#2d004f'
  on-primary-fixed-variant: '#632892'
  secondary-fixed: '#59fdc5'
  secondary-fixed-dim: '#2fe0aa'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#00513b'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  numeric-ticker:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system embodies institutional heritage engineered with contemporary retail fintech clarity. Built specifically for conversational stock intelligence and market advisory, it pairs the structured, trustworthy authority of Aditya Birla with the approachable, frictionless simplicity popularized by next-gen platforms like Groww.

### Target Audience & Emotional Intent
- **Audience:** Savvy retail investors, young professionals executing self-directed wealth planning, and seasoned market participants requiring rapid, real-time corporate equity breakdowns.
- **Emotional Response:** Lucid transparency, quiet competence, speed without overwhelm, and absolute structural precision. Users must feel in control of high-stakes financial data within an open, breathing visual environment.

### Design Movement & Aesthetic
- **Minimalist Structural Modernism:** Driven by stark, pure white fields, hairline borders, zero decorative gradients, and high typographic rigor.
- Visual weight is communicated strictly through typographic density, systematic line work, and tactical, razor-sharp color accents—eliminating visual noise to highlight key transactional and performance metrics.

## Colors

The palette is engineered for clinical legibility and intuitive market orientation on a pure light surface.

- **Primary (`#581C87`):** The signature Birla deep imperial purple. Used for active institutional touchpoints, key interactive triggers, conversational prompt anchors, and user speech bubbles.
- **Secondary (`#00D09C`):** Vibrant Groww-inspired mint/emerald. Reserved strictly for positive value differentials, buy signals, bullish market momentum, and active market status badges.
- **Tertiary (`#EF4444`):** Crisp signal crimson. Exclusively allocated for sell signals, bearish pullbacks, and cautionary alerts.
- **Neutral Core:**
  - Canvas: Pure White (`#FFFFFF`) and pristine surface off-white (`#F9FAFB`).
  - Text: High-contrast Dark Charcoal (`#111827`) for headlines and critical numbers, Slate Charcoal (`#374151`) for body narrative, Muted Slate (`#4B5563`) for metadata, and Neutral Grey (`#6B7280`) for micro-captions.
- **Borders & Dividers:** Subtle, razor-sharp separators (`#E5E7EB` for interactive container walls and structural dividers; `#F3F4F6` for inner micro-separators).

## Typography

The typography system relies exclusively on **Inter** to ensure maximum digital clarity, optical balance at small sizes, and platform-native familiarity.

- **Tabular Figures:** All numeric financial metrics, percentage badges, strike prices, and live ticker feeds must render with tabular figures (`font-variant-numeric: tabular-nums`) to prevent optical shifts during data refreshes.
- **Hierarchy Rules:** Conversational user bubbles leverage `body-md` in regular weight. Financial stock cards prioritize `headline-sm` for the stock symbol paired with `label-sm` for corporate subtext.
- **Line Heights:** Tightly constrained line heights across numerical labels maintain compact card layouts, while body copy preserves generous breathing room (`1.45` to `1.5` ratio) to support readability during dense financial explanations.

## Layout & Spacing

The layout is built for a mobile-first, vertical viewport experience, optimizing single-handed interactions within the conversational thread.

- **Grid & Safe Margins:**
  - Viewport margin is fixed at `1rem` (16px) on mobile, locking the chat conversation stream and input bar into consistent vertical gutters.
  - Columnar data inside cards adheres to a flexible 4-column sub-grid with `0.75rem` (12px) gutters.
- **Chat Rhythm:**
  - Inter-message vertical spacing: `1rem` between distinct speakers; `0.25rem` between sequential messages from the same sender.
  - Interactive chip suggestions and carousel cards sit inside an edge-to-edge horizontally scrollable rail with `1rem` starting offset padding.
- **Adaptive Bounds:**
  - While optimized for narrow viewports (`360px` to `430px`), wider surfaces wrap the conversational frame to a centered max-width of `480px`, preventing unstructured horizontal line stretch.

## Elevation & Depth

Visual separation relies on strict structural containment rather than heavy drop shadows, reinforcing the clean, flat fintech philosophy.

- **Low-Contrast Outlines:** Surfaces gain definition via 1px crisp borders in `#E5E7EB`. Depth is established purely by layering white `#FFFFFF` cards over an ultra-faint surface backdrop (`#F9FAFB`).
- **Floating Controls (Input Shell):** The persistent bottom chat action bar is the only elevated surface, anchored with an ambient, diffused grounding shadow: `0 -4px 16px rgba(17, 24, 39, 0.04)`.
- **Zero Gradient Policy:** No atmospheric blurs, skeuomorphic glows, or multi-stop gradients are permitted. Visual priority is dictated strictly by contrasting color blocks against clean neutral borders.

## Shapes

The interface employs moderate, calculated rounding to project high-tech polish while remaining crisp and structured.

- **Standard Containers & Cards (`rounded-lg` / 1rem):** Financial insight cards, market summary modules, and order preview sheets use a 16px corner radius.
- **Chat Bubbles:**
  - Assistant response bubbles: 16px roundedness on all corners except the bottom-left anchor (4px).
  - User response bubbles: 16px roundedness with a flattened bottom-right anchor (4px).
- **Interactive Chips & Badges:** Use total pill rounding (`rounded-full` / 9999px) to communicate immediate tap affordance and contrast with square structural content cards.

## Components

### 1. Conversational Chat Bubbles
- **Bot/Assistant Module:** Background `#FFFFFF`, border 1px solid `#E5E7EB`, text `#111827`. Contains an avatar chip sporting the primary `#581C87` monogram.
- **User Module:** Background `#581C87`, text `#FFFFFF`, borderless, aligned right with 80% maximum viewport width.

### 2. Market Snapshot & Stock Cards
- Flat `#FFFFFF` container with a 1px solid `#E5E7EB` border.
- Top section: Company name (`#111827`, `headline-sm`) and NSE/BSE tracker badge (`#6B7280`, `label-sm`).
- Center section: Live price (`#111827`, `headline-md`, tabular) alongside a pill-shaped indicator containing the delta (e.g., `+2.45%` in `#00D09C` on `#ECFDF5` background; `-1.12%` in `#EF4444` on `#FEF2F2` background).
- Lower section: 2-column or 3-column data grid showcasing P/E Ratio, 52W High, and Market Cap separated by `#F3F4F6` vertical hairline dividers.

### 3. Action Chips & Prompt Suggestions
- Horizontal scroller hosting quick contextual prompts (e.g., *"Show Q3 Results"*, *"Bullish Technicals"*, *"Compare with peers"*).
- Border: 1px solid `#E5E7EB`, background `#FFFFFF`, text `#374151` (`label-md`).
- Active/Pressed state: Background `#F3F4F6`, border `#D1D5DB`.

### 4. Chat Input Bar
- Pinned bottom bar housing a subtle `#F3F4F6` inner track with zero border, text input (`body-md`), a mic icon (`#6B7280`), and an active circular send button in `#581C87` with a pure white glyph.

### 5. Buy / Sell CTAs
- **Primary Execution (Buy):** Mint background `#00D09C`, text `#FFFFFF`, 0.75rem vertical padding, semi-bold typography, flat finish.
- **Secondary Execution (Sell):** Neutral outline or crimson text styling depending on user flow urgency.